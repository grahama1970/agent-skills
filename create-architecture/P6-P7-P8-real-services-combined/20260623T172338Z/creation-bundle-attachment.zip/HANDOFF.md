# HANDOFF.md

# Handoff Report: Personaplex P6-P7-P8 Real Services Combined Slice

**Timestamp:** 2026-06-23T17:23:38Z
**Status:** Synthesized `$create-architecture` handoff after P3-P5 deterministic fallback checkpoint.
**Rendered progress page:** `reviews/personaplex-deepgram/compliance-memory-decision-tree.html` served at `http://127.0.0.1:8771/reviews/personaplex-deepgram/compliance-memory-decision-tree.html`

## What Exists Now

P0/P1/P2/P3-P5 are deterministic/local proof slices already ported into `skills/personaplex`.

P3-P5 added combined deterministic fallback for WebSocket, memory upsert, and evidence-case routing. The adapters exist (`personaplex_p3_p5_live_services.py`) but are configured to use `MEMORY_URL=""` and `EVIDENCE_CASE_URL=""` with deterministic file-backed fallback.

## Concrete P3-P5 Proof

- **Solution zip:** `personaplex-p3-p5-live-websocket-memory-evidence-combined-solution.zip`
- **SHA-256:** `46f9caa2153bfdbe5ea01ced76bb56b02c6afc567f6859e3f61bbef88df05fce`
- **Focused tests:** `Ran 6 tests, OK`
- **Combined PersonaPlex tests:** `Ran 26 tests, OK`
- **Final receipt:** `/tmp/personaplex-p3-p5-combined-sanity/p3-p5-final-receipt.json`

Receipt anchors:
- `ok=true`, `turn_count=2`, `active_turn_id=2`
- `stale_rejection_count=1`, `queue_depth_at_release=0`
- `live_websocket=false`, `real_deepgram=false`, `real_gpu_personaplex=false`
- `real_memory_upsert=false`, `real_create_evidence_case=false`
- `memory_url_not_configured` and `evidence_case_url_not_configured`

## Endpoint Discovery (Completed for This Bundle)

Found by auditing the memory project at `/home/graham/workspace/experiments/memory`:

| Service | URL | Method | Request Schema |
|---------|-----|--------|----------------|
| Memory upsert | `http://127.0.0.1:8601/upsert` | POST | `{"collection": str, "documents": [{_key, ...}], "skip_embedding": bool}` |
| Evidence case | `http://127.0.0.1:8601/create-evidence-case` | POST | `{"question": str, "context_framework": str?, "enable_llm": bool, "include_cae_tree": bool, "fail_on_degraded_evidence": bool}` |
| Deepgram WebSocket | `wss://api.deepgram.com/v1/listen` | WS | API key from `DEEPGRAM_API_KEY` env var |

## Current Defects / Missing Rows

1. Memory upsert adapter exists but `MEMORY_URL` is empty — no real 2xx upsert proven.
2. Evidence-case adapter exists but `EVIDENCE_CASE_URL` is empty — no real response proven.
3. Deepgram WebSocket adapter uses `deterministic_transcript_fixture` — no real `speech_final=true` from Deepgram's servers.
4. GPU PersonaPlex inference not proven (deferred).
5. Conversation compaction not implemented (deferred to P9).

## Files Likely In Scope

- `skills/personaplex/scripts/personaplex_p3_p5_live_services.py` — adapter needs real URL wiring
- `skills/personaplex/scripts/personaplex_p3_p5_combined_probe.py` — probe needs to accept real endpoints
- `skills/personaplex/scripts/personaplex_deepgram_live.py` — may need env-var or config-key wiring
- `skills/personaplex/scripts/personaplex_golden_state_server.py` — may need config pass-through
- `skills/personaplex/sanity_p3_p5_live_websocket_memory_evidence_combined.sh` — update with real-service variants
- `skills/personaplex/tests/test_p3_p5_live_websocket_memory_evidence_combined.py` — update with live-service tests
- New dedicated sanity scripts per service target

## Must Not Disturb

- Do not replace the project agent's P0/P1/P2/P3-P5 architecture with a new local design.
- Do not claim real service proof from deterministic fixture receipts.
- Do not store inline vectors in Arango-shaped records.
- Do not make `personaplex_turns` canonical.
- Do not use generic zip names or omit `MANIFEST.json.bundle_filename`.

## Next Build Step (After This Zip)

Port the real-service wiring, run focused tests per target, update the HTML progress gaps table (mark P6/P7/P8 rows according to real-vs-fallback), then start the next WebGPT round for compaction or GPU proof if remaining.