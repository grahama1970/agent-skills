# GOAL.md

# Goal: PersonaPlex P6-P7-P8 Real Services Combined Slice

## Rendered Progress Report

Repo path: `reviews/personaplex-deepgram/compliance-memory-decision-tree.html`
Served URL: `http://127.0.0.1:8771/reviews/personaplex-deepgram/compliance-memory-decision-tree.html`

## Objective

Extend the P3-P5 deterministic adapters to reach actual live services. Each adapter
already has a configurable URL/endpoint and deterministic file-backed fallback.
This slice wires the URLs, adds acceptance tests that try the real endpoint and
record whether it succeeded or fell back to deterministic mode, and updates the
receipt `real_*` flags honestly.

## Non-Goals

- No new conversation compaction logic (P9).
- No GPU PersonaPlex owner-loop proof (separate round).
- No browser-level microphone/WebRTC integration.

## Service Endpoints (Discovered)

1. **Memory upsert:** `POST http://127.0.0.1:8601/upsert`
   Body: `{"collection": "conversation_history", "documents": [{"_key": "...", "turn_id": 1, "transcript": "..."}], "skip_embedding": false}`
2. **Evidence case:** `POST http://127.0.0.1:8601/create-evidence-case`
   Body: `{"question": "Focus on the west gateway.", "context_framework": "SPARTA", "enable_llm": false, "include_cae_tree": false, "fail_on_degraded_evidence": false}`
3. **Deepgram WebSocket:** `wss://api.deepgram.com/v1/listen` with `DEEPGRAM_API_KEY` env var

## Acceptance Gates

### P6: Real Memory Upsert Gate

- Probe script sets `MEMORY_URL=http://127.0.0.1:8601` and sends a real `POST /upsert`.
- If daemon responds 2xx: receipt `real_memory_upsert=true`, response status/body excerpt recorded.
- If daemon is unreachable: receipt `real_memory_upsert=false`, reason documented, deterministic fallback used.
- No inline vectors in payload. `retrieval_text` present in documents.

### P7: Real Evidence-Case Gate

- Probe script sets `EVIDENCE_CASE_URL=http://127.0.0.1:8601` and sends a real `POST /create-evidence-case`.
- If daemon responds 2xx: receipt `real_create_evidence_case=true`, response excerpt recorded.
- If daemon is unreachable: receipt `real_create_evidence_case=false`, fallback to `/memory /clarify`.
- No substantive compliance claim released without evidence-case or clarify packet.

### P8: Live Deepgram WebSocket Gate

- Probe script sources `DEEPGRAM_API_KEY` from `~/.zshrc` and opens a live Deepgram WebSocket.
- If Deepgram is reachable: receipt `real_deepgram=true`, at least one `speech_final=true` event observed.
- If key is missing or endpoint unreachable: receipt `real_deepgram=false`, `deepgram_mode=deterministic_transcript_fixture`.
- GPU PersonaPlex is NOT required for this gate (separate).

## Required Files In The Zip

WebGPT should choose exact files, but expected file classes include:

- `ARCHITECTURE.md` for P6-P7-P8 wiring
- `MANIFEST.json` with `bundle_filename`
- `prompt_improvements.md`
- Updated `personaplex_p3_p5_live_services.py` with real URL configuration
- New or updated sanity scripts:
  - `sanity_p6_real_memory_upsert.sh`
  - `sanity_p7_real_evidence_case.sh`
  - `sanity_p8_live_deepgram.sh` (or combined)
- Updated `test_p3_p5_live_websocket_memory_evidence_combined.py` or new per-target test files
- Updated combined probe module if needed
- Fixture data for deterministic fallback

## Required Proof Commands

The zip must include exact commands to run. They should be runnable from repo root after porting, and should produce JSON receipts under `/tmp/personaplex-p6-p7-p8-sanity/`.

## Project-Agent / WebGPT Division

WebGPT creates the entire wiring extension as files. The project agent will only:

- download and checksum the zip;
- run isolated sanity;
- port files mechanically (overlay on existing adapters);
- fix light integration bugs without changing architecture;
- run local proof commands per target;
- update HTML report, gap report, and handoff;
- start another WebGPT round if required rows remain MISSING.