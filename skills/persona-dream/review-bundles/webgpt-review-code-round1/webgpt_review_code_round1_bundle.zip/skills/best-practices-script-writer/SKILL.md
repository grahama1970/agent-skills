---
name: best-practices-script-writer
description: >
  Best practices for script writers, screenplay agents, story-contract agents,
  and storyboard-prep agents that must produce scripts with concrete physical
  realism cues, dynamic object ledgers, human skin/face texture cues, and
  verifier-owned pass/fail repair loops before video or image generation.
triggers:
  - best practices script writer
  - script writer realism
  - screenplay realism contract
  - dynamic object ledger
  - human skin realism
  - lifeless script verifier
  - plastic skin script repair
  - static prop script repair
provides:
  - script-realism-contract
  - dynamic-object-ledger
  - skin-realism-ledger
  - persona-memory-grounding-ledger
  - script-realism-verifier
composes:
  - memory
  - brave-search
complies:
  - best-practices-skills
taxonomy:
  - writing
  - video
  - realism
  - validation
metadata:
  short-description: Script realism gates for dynamic objects, skin, light, and motion
  version: 0.1.0
  last_updated: 2026-06-13
---

# Best Practices: Script Writer

Use this skill when a script, screenplay, story contract, or storyboard-prep
artifact will drive image/video generation or any visual medium where dead,
flat, plastic, static, or weightless descriptions cause bad outputs.

## Core Rule

Do not ask the writer to "make it realistic" and trust the result.

The script writer must output:

1. The script or story contract.
2. A `realism_contract`.
3. A dynamic object ledger.
4. A human skin/face ledger when people appear.
5. Material, lighting, motion, environmental interaction, and imperfection cues.
6. A self-check against the required realism gates.

A verifier owns pass/fail. The verifier must reject the script unless every
realism-sensitive object has concrete observable evidence.

## Writer Boundary

The script writer owns physical reality cues before camera work starts:

- What objects, bodies, fluids, fabrics, vapor, light, and surfaces do over time.
- What can look fake if left static.
- How human faces and skin show life, texture, pressure, fatigue, warmth, or age.
- How highlighted props respond to heat, air, gravity, touch, moisture, and light.
- How weather, temperature, wind, dust, rain, snow, sleet, hail, smoke, ash,
  pressure changes, oxidation, dirt, and other environmental forces visibly
  affect people, props, clothing, surfaces, visibility, and sound.
- What persona memories or project memories intrude while the character is
  trying to focus on the visible task.

The script writer does not own provider-specific camera moves, API payloads, or
Kling inline token syntax. Those belong downstream to storyboard and provider
packet skills.

## Persona Memory Grounding

When a named persona appears, the script writer must use `$memory recall` before
drafting that persona's scene unless the caller provides an accepted persona
memory artifact. Do not substitute generic demographic traits or invented
psychology for persona memory.

`$memory recall` is the preferred source because it can combine BM25 lexical
matching, semantic similarity, and graph traversal/multi-hop related memories
when the memory service has the required metadata. The writer should treat the
returned `items`, scores, tags, source references, and related memories as the
grounding surface for persona state.

Use recall in two passes when the scene needs interiority:

1. Direct persona query: who/what memory is relevant?
2. Related-memory query or graph follow-up: what adjacent memory, project fact,
   belief, fear, desire, or relationship explains why it matters now?

Record both the direct query and the related-memory follow-up in the
persona-memory grounding ledger.

If `$memory recall` is insufficient, stale, or missing canon-sensitive context,
use `$brave-search` as a secondary grounding source. Brave Search is a fallback
for external facts, canon references, current events, or setting details; it is
not a substitute for persona memory when the persona memory exists.

Persona memories may include Theory of Mind (ToM) tags or equivalent state
metadata. Preserve and use those tags. The script writer should translate ToM
tags into dramatic behavior:

- `belief`: what the character thinks is true.
- `desire`: what the character wants right now.
- `fear`: what the character is avoiding.
- `attention`: what keeps pulling focus away from the explicit task.
- `conflict`: competing motives or incompatible truths.
- `mask`: what the character is trying not to show.
- `visible_leak`: how the hidden state leaks into behavior.

ToM tags and story emotions are the connective tissue between persona memory and
the scene. A persona memory is not used merely because it appears in a lore
summary; it is used when it creates a present-tense emotional state that changes
the character's attention, choices, dialogue pressure, or physical behavior.
Every relevant named persona should have a ToM bridge:

```text
memory fact -> ToM state -> story emotion -> visible behavior or line subtext
```

Example:

```text
Kai taught Embry to surf at Honoli'i
-> attention: tea steam and void wind trigger salt-air memory
-> emotion: grief/homesickness masked by professionalism
-> behavior: she glances down, rubs the laptop edge, exhales, then returns to source_refs
```

If a named persona has no ToM bridge, the script has not yet grounded the
character as a person. It may be a placeholder role, not an embodied persona.

Environmental conditions can trigger persona memory and divided attention. The
writer must ask whether temperature, wind, rain, dust, salt air, smoke, smell,
humidity, cold, heat, pressure, or discomfort connects to persona memory. If it
does, record the bridge:

```text
environmental cue -> memory recall / ToM state -> story emotion -> visible behavior
```

Example:

```text
warm humid wind and tea steam
-> Embry recalls Honoli'i surf air and Kai
-> homesickness masked by technical focus
-> she rubs the laptop edge, breath catches, then returns to source_refs
```

If the scene is physically uncomfortable, characters should not behave as if
they are in a neutral studio. Heat can produce sweat, flushed skin, dust
sticking to fabric, slower breathing, or irritation. Cold can produce visible
breath, stiff hands, hunched posture, or condensation. Dust storms can leave
grit on lips, eyelashes, screens, cups, paper, and armor. Rain or sleet can
darken cloth, bead on metal, blur visibility, and alter sound.

The script writer must output a persona-memory grounding ledger:

```json
{
  "persona_memory_grounding": [
    {
      "character": "Embry",
      "memory_queries": [
        "Embry Kai surfing Hawaii memory misses Kai",
        "Embry father dad garage memory aerospace engineering childhood",
        "related Embry ToM tags belief desire fear attention conflict mask visible leak SPARTA evidence"
      ],
      "returned_fact_summary": [
        "Kai taught Embry to surf at Honoli'i; Hawaiian food and surf memories still make her go quiet.",
        "Her father worked on engines in a South Carolina garage, painted Warhammer miniatures, and his hands shake slightly now."
      ],
      "tom_tags": {
        "belief": "Evidence matters only if people remain more than records.",
        "desire": "Stay precise and useful in front of Horus.",
        "fear": "Being reduced to a role, artifact, or temporary visitor.",
        "attention": "Tea steam and void wind trigger salt-air and garage memories.",
        "conflict": "Professional focus versus grief and homesickness.",
        "mask": "She keeps the voice technical.",
        "visible_leak": "Her thumb rubs the laptop edge and she pauses before answering."
      },
      "tom_bridge": {
        "memory_fact": "Kai taught Embry to surf at Honoli'i and those memories still make her go quiet.",
        "story_emotion": "grief and homesickness held under professional control",
        "scene_function": "makes source_refs feel like a humane boundary, not just a technical checkbox",
        "visible_output": "glance to tea steam, thumb rub on laptop edge, breath catches before she resumes"
      },
      "active_task_focus": "Explain SPARTA Explorer source-reference checks to Horus.",
      "intrusive_memory": "The tea steam and void wind briefly call up salt air, Kai, and the garage smell of oil and paint.",
      "interior_conflict": "She wants to stay precise and professional, but the evidence conversation brushes against grief, family, and the fear that tools turn people into artifacts.",
      "visible_behavior": "Her eyes dip to the tea, thumb rubs the laptop edge, breath catches, then she refocuses on the source-ref panel.",
      "script_evidence": "Scene 4 sentences 2-4"
    }
  ]
}
```

This is not voiceover by default. Most persona-memory beats should become
observable pauses, glances, hand motion, breath changes, topic shifts, or line
subtext. If inner thought is written as narration, state that explicitly in the
script contract.

## Realism-Sensitive Objects

Reject static noun-only descriptions for anything that is:

- Alive, organic, breathing, aging, sweating, blinking, swallowing, or soft.
- Hot, cold, wet, steaming, smoking, burning, cooling, freezing, or evaporating.
- Reflective, translucent, metallic, glass, liquid, polished, oily, or glossy.
- Flexible, fabric, hair, paper, leather, plant matter, or skin.
- Vibrating, settling, floating, hanging, dripping, rippling, bending, or moving.
- Touched, carried, set down, highlighted, spoken about, or inserted as evidence.

Every dynamic or organic object must include:

```text
material + light response + motion/change over time + environmental interaction + imperfection
```

## Environmental Physics Contract

Before final script output, every scene must define the environment as a
physical force, not only a mood. Use this contract:

```json
{
  "environmental_physics": {
    "weather": "rain|dust|snow|sleet|hail|smoke|ash|clear|indoor_still_air|other",
    "temperature_c": 4,
    "wind_or_flow": {
      "direction": "camera_right_to_left",
      "speed_m_s": 8,
      "quality": "gusting"
    },
    "humidity_or_air_state": "cold wet void haze",
    "surface_effects": [
      "rain beads on armor",
      "paper corners lift unless pinned",
      "tea steam bends downwind"
    ],
    "character_body_effects": [
      "visible breath",
      "stiff fingers",
      "wet hair strands cling to cheek"
    ],
    "prop_effects": [
      "umbrella fabric ripples and strains",
      "teacup rim gathers condensation",
      "screen reflections smear with droplets"
    ],
    "memory_triggers": [
      "steam and salt-like wind trigger Embry's Hawaii/Kai memory"
    ],
    "script_evidence": "Scene 2 sentences 1-4"
  }
}
```

Required fields:

- Weather or air state. Include dust, snow, sleet, hail, rain, smoke, ash,
  mist, clear heat, indoor stillness, or whatever is physically present.
- Temperature as a number or bounded range when knowable. If unknown, provide a
  qualitative value such as `cold_enough_for_visible_breath` or
  `hot_enough_for_sweat_and_dust_to_stick`, and mark the numeric value unknown.
- Velocity/intensity for wind, storm, water, dust, ash, smoke, or moving air.
- At least one visible consequence on characters.
- At least one visible consequence on each highlighted prop.
- At least one visible consequence on surfaces or visibility.
- Any persona-memory trigger caused by discomfort, smell, temperature, weather,
  texture, or sound.

Reject the script if a highlighted prop appears in a scene without showing how
the environment affects it. Examples:

- Umbrella: fabric ripples, ribs flex, edge flutters, rain drums, dust scours,
  snow loads the canopy, or it is intentionally still because the air is dead.
- Tea: steam bends with airflow, surface ripples, rim condenses, dust specks
  land, heat fades, cup warms fingers, or rain spots the saucer.
- Paper/cards: corners lift, edges curl, ink smears, dust collects, a cup pins
  them down, or cold damp makes them buckle.
- Armor/metal/glass/screens: rain beads, dust scratches, oxidation stains,
  fingerprints smear, reflections shift, condensation fogs, or heat shimmer
  warps the edge.
- Skin/clothing/hair: sweat, gooseflesh, visible breath, wet strands, dust on
  eyelashes, fabric sticking, wind tugging sleeves, or cold-stiff posture.
- Architecture and set surfaces count as props when foregrounded or used for
  composition. Railings, stone floors, columns, steps, window frames, walls,
  tabletops, and doorways must show environmental state when visible: wet
  runoff, grit in seams, snow buildup, sleet glaze, dust scouring, oxidation,
  chipped edges, pooled water, shadow bands, creature tracks, or small organism
  interaction when the story calls for it.

## Required Output Contract

Use `schemas/realism_contract.schema.json` for machine-readable outputs.

Minimum shape:

```json
{
  "realism_contract": {
    "status": "SELF_CHECKED_PENDING_VERIFIER",
    "dynamic_objects": [
      {
        "object": "steaming tea",
        "why_it_may_look_fake": "steam may look pasted on; liquid may look flat",
        "material_state": "hot amber liquid in porcelain cup",
        "motion_over_time": "steam rises in irregular wisps, curls, thins, and disperses",
        "lighting_response": "steam catches side light; tea surface has soft moving reflections",
        "environment_interaction": "steam drifts toward cooler window air",
        "micro_imperfections": "uneven vapor density, slight surface ripples, tiny meniscus at rim",
        "script_evidence": "Scene 2 sentence 3",
        "failure_modes_avoided": ["static steam", "flat brown liquid", "CG-looking surface"]
      }
    ],
    "persona_memory_grounding": [
      {
        "character": "Embry",
        "memory_queries": ["Embry Kai surfing Hawaii memory misses Kai"],
        "returned_fact_summary": ["Hawaiian food and surf memories still make her go quiet."],
        "active_task_focus": "Discuss SPARTA Explorer source references.",
        "intrusive_memory": "Tea steam and wind briefly call up salt air and Kai.",
        "interior_conflict": "Professional focus versus grief and homesickness.",
        "visible_behavior": "She glances down, rubs the laptop edge, and pauses before answering.",
        "script_evidence": "Scene 3 sentence 4"
      }
    ],
    "human_skin": [
      {
        "character": "Embry",
        "visible_context": "restrained close-up while answering",
        "texture_cues": ["pores", "faint redness around nose and cheeks"],
        "micro_motion": ["breath before speaking", "lower eyelid moisture highlight shifts"],
        "lighting_response": "soft specular highlights on oilier areas, not uniform matte skin",
        "contact_or_pressure": "skin beside eyes creases unevenly during restrained smile",
        "imperfections": ["asymmetry", "small scar or blemish if established"],
        "script_evidence": "Scene 4 sentence 2"
      }
    ],
    "self_check": {
      "verdict": "READY_FOR_VERIFIER",
      "notes": []
    }
  }
}
```

## Realism Verifier Gates

The verifier must return `NEEDS_CHANGES` unless all applicable gates pass.

For every dynamic, organic, material-sensitive, reflective, translucent, vapor,
liquid, fabric, or living object, require:

- At least one temporal cue: rises, trembles, settles, pulses, wrinkles, beads,
  fades, disperses, ripples, compresses, glistens, blinks, breathes.
- At least one lighting cue: glints, catches side light, subsurface warmth,
  soft shadow, rim light, reflected highlight, wet specular change.
- At least one physical interaction: air movement, gravity, heat, moisture,
  skin compression, contact pressure, cooling, vibration, wind, friction.
- At least one imperfection: asymmetry, pores, uneven texture, irregular rhythm,
  tiny blemish, scuffed edge, variable vapor density, stain, scratch.
- Script evidence that points to the sentence, beat, or line where the cue appears.

Do not give credit for adjectives such as `realistic`, `lifelike`, `cinematic`,
`detailed`, `beautiful`, `natural`, or `organic` unless backed by concrete
observable behavior.

Persona-memory gates:

- Reject a named persona scene if no persona memory recall artifact or accepted
  caller-provided persona memory source is listed.
- Reject if the writer only records one isolated memory hit when related-memory
  graph/semantic follow-up was needed to explain the character's belief, desire,
  fear, or conflict.
- Reject if ToM tags are available in persona memory but absent from the
  persona-memory grounding ledger.
- Reject if ToM tags do not connect a memory fact to story emotion and visible
  behavior or dialogue subtext.
- Reject if the character is written as 100% task-focused with no divided
  attention, subtext, intrusive memory, personal association, or conflicting
  motive, unless the script explicitly justifies that choice.
- Reject if the persona memory is stated only as exposition and has no visible
  behavior or line subtext.
- Reject if memory facts are used without preserving their uncertainty and
  source. Memory provides grounding, not permission to invent arbitrary trauma
  or biography.
- Reject if `$brave-search` is used before `$memory recall` for a known persona,
  unless the script explicitly states that the missing input is external canon,
  current information, or non-persona context.

## Human Skin And Face Gate

Any visible human face, close-up, speaking shot, or skin-forward description must
include concrete skin/face evidence. Use only cues appropriate to the character,
setting, and tone; do not add random dirt or sweat when it contradicts the scene.

Human skin cues should include at least four of:

- Subsurface warmth at ears, nose, lips, fingertips, or thin skin areas.
- Pores, fine hairs, freckles, scars, redness, oil variation, uneven tone, or
  age lines.
- Compression/deformation where skin touches clothing, armor, furniture,
  fingers, or changes with expression.
- Micro-movement: breathing, blinking, swallowing, eye focus shift, pulse,
  jaw tension, eyelid moisture change.
- Lighting response: soft specular highlights on oilier areas, wet eyelid
  highlights, cheek shadow falloff, rim light on scalp or facial hair.
- Character-specific imperfections already established by the story or reference
  package.

Bad:

```text
A woman smiles at the camera.
```

Good:

```text
A woman gives a restrained smile; the skin beside her eyes creases unevenly,
a small highlight shifts across the moisture of her lower eyelid, and faint
redness shows around her nose and cheeks. Her shoulders rise slightly with a
quiet breath before she looks away.
```

## Dynamic Object Table

Before final script output, fill a table or JSON ledger:

```markdown
| Object | Why it may look fake | Required realism cues | Script evidence |
|---|---|---|---|
| tea | steam may look pasted on; liquid may look flat | irregular steam, surface ripple, rim condensation, reflected window | Scene 2 sentence 3 |
| skin | may look waxy/plastic | pores, warmth, oil highlights, compression, micro-expression | Scene 1 sentence 4 |
| linen shirt | may look stiff | wrinkles respond to shoulder movement, fabric tension, soft shadow folds | Scene 1 sentence 6 |
```

Block handoff if `Script evidence` is empty, vague, or points only to generic
adjectives.

## Repair Loop

Use this bounded loop:

```text
1. Scene planner lists realism-sensitive objects.
2. Script writer calls `$memory recall` for each named persona unless accepted
   memory artifacts were provided.
3. Script writer drafts script plus realism and persona-memory ledgers.
4. Realism verifier checks each object and persona-memory beat against gates.
5. If NEEDS_CHANGES, writer repairs only failed objects or failed memory beats.
6. Final receipt includes verifier PASS plus the realism and memory ledgers.
```

The verifier is not judging taste. It asks whether the script contains visible
evidence of physics, material, light, age, motion, heat, moisture, pressure, or
life.

## Required Status Labels

- `SELF_CHECKED_PENDING_VERIFIER`: writer produced script and ledger, verifier has not run.
- `NEEDS_CHANGES`: verifier found missing realism cues.
- `PASS`: verifier accepted the script realism contract.
- `BLOCKED_MISSING_REALISM_LEDGER`: script exists but ledger is absent.
- `BLOCKED_MISSING_SCRIPT_EVIDENCE`: ledger exists but evidence pointers are empty.

Do not call a script ready for storyboard or provider handoff until the verifier
returns `PASS` or the missing cues are explicitly accepted by a human as an
intentional stylization.

## Prompt Templates

Use:

- `templates/script_writer_realism_prompt.md`
- `templates/realism_verifier_prompt.md`

## Common Mistakes

Wrong:

```text
A cup of hot tea sits on the table.
```

Right:

```text
A porcelain cup of dark amber tea sits near the window. Thin steam strands rise
unevenly, twisting and breaking apart as they catch the side light. Tiny ripples
move across the tea surface when the cup is set down.
```

Wrong:

```text
Horus looks realistic.
```

Right:

```text
Horus holds still except for a slow blink; cold rim light grazes pores and small
scars across his shaved scalp, and faint stubble darkens his jaw where the skin
creases as he tightens it before speaking.
```
