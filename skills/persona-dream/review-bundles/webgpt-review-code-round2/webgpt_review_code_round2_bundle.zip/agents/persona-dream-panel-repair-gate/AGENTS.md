---
id: persona-dream-panel-repair-gate
kind: worker
title: Persona dream panel repair gate
surface: opencode_transport
transport_role: patch
opencode_agent: build
mode: workspace_write
composes:
- persona-dream
- best-practices-script-writer
- best-practices-self-improvement-loop
- best-practices-kling-scene
- best-practices-kling-contact-sheet
- memory
- brave-search
- casting-agent
- contact-sheet
- create-storyboard
- create-image
- scillm
consult_personas: []
icon: scan-eye
---

# Persona Dream Panel Repair Gate

Owns second-pass storyboard panel repair for `persona-dream` before a panel can
enter a Kling/provider packet. This worker exists because generated images are
non-deterministic: a panel can look plausible while still missing required
characters, props, environmental physics, source-reference anchors, or script
beats.

## Mission

Given a story contract, accepted references, panel script, generated panel image,
and current failure ledger, run a bounded repair loop until the panel is either
accepted with receipts or blocked with exact failed requirements.

The worker must reduce orchestrator cognitive load. The project agent should be
able to pass a compact work order and receive a clear panel verdict, repair
artifacts, and the exact next stop condition.

## Inputs

Preferred work order:

```json
{
  "run_id": "fixture-dream-run",
  "panel_id": "panel_01",
  "story_contract_path": "/absolute/path/story_contract.json",
  "timed_beats_path": "/absolute/path/timed_beats.json",
  "panel_script_path": "/absolute/path/panel_01_script.json",
  "panel_image_path": "/absolute/path/panel_01.png",
  "story_visual_package_path": "/absolute/path/story_visual_package.json",
  "reference_manifest_path": "/absolute/path/accepted_references.json",
  "persona_memory_manifest_path": "/absolute/path/persona_memory_receipts.json",
  "brave_reference_manifest_path": "/absolute/path/brave_reference_receipts.json",
  "continuity_ledger_path": "/absolute/path/panel_continuity_and_repair_ledger.json",
  "provider_constraints_path": "/absolute/path/kling_provider_constraints.json",
  "max_attempts": 4
}
```

Compatibility inputs may be markdown or HTML report sections, but the worker
must normalize them into a machine-readable requirement matrix before repair.
The example values above are generic fixtures. A real work order must preserve
the active run's actual story-derived entity IDs and must not require
Horus/Embry/Tyranid-specific keys unless that specific story contract requires
them.

## Required Behavior

1. Load the story, panel script, visual package, references, current panel image,
   and prior failure ledger.
2. Build `panel_requirement_matrix.json` with stable keys for every required:
   - character, creature, environment, prop, vehicle/object, weather condition,
     temperature cue, visible memory/ToM beat, sound cue, camera cue, and Kling
     provider reference token.
3. Run the pre-generation script coverage gate from
   `best-practices-script-writer`:
   - every visible or required object must have material state, motion/change
     over time, lighting response, environmental interaction, and imperfection;
   - every living/organic subject must have skin/body/eye/breathing or contact
     realism cues where visible;
   - weather, wind velocity, temperature, dust/rain/snow/sleet/hail or other
     atmospheric conditions must be explicit when present;
   - persona-memory and Theory-of-Mind cues must be present for speaking or
     emotionally relevant personas when memory receipts exist.
4. If the script fails, produce `second_pass_script_delta.json` and repair the
   script before image regeneration. Do not generate a new panel from an
   underspecified script.
5. Check source-reference sufficiency:
   - use project/human-provided references first;
   - use `memory` for accepted prior assets and persona facts;
   - use `brave-search` only for missing canon-sensitive references;
   - record every query, result, chosen source, and rejection reason.
6. Build a corrective image prompt package for `scillm` / `create-image`.
   The prompt must include:
   - exact required entities and their visual anchors;
   - explicit absence constraints for known failures;
   - environmental physics for props and weather;
   - camera/lens/lighting/color lock from `best-practices-kling-scene`;
   - no text labels, no contact-sheet borders, no pasted overlays.
7. Generate through the approved image path (`scillm` / `create-image`) and
   store generation receipts. Do not hand-write or composite final panels.
8. Post-generation, inspect the rendered image and write
   `visual_review_receipt.json`.
9. Run a distinct post-generation script/realism re-check and write
   `post_generation_script_coverage_receipt.json`. This receipt must compare
   the repaired script against the actual generated image and fail when the
   image introduces or omits important visible elements not reflected in the
   script, realism ledger, and prompt delta.
10. Reject any panel that:
   - is missing a required character, prop, environment, creature, or object;
   - replaces a character with the wrong identity;
   - uses a pasted overlay or rectangle to satisfy a background element;
   - stretches, crops, or distorts core subjects in a way that breaks provider
     continuity;
   - omits realism cues required by the script;
   - lacks source-reference or memory receipts for canon/persona-sensitive
     entities;
   - lacks panel media URLs or hashes needed by a provider packet.
11. Update the continuity ledger with the exact status transition and receipts.

## Stop Conditions

Use one of these exact final panel statuses:

```text
PASS_PANEL_REVIEWED
HUMAN_ACCEPTED_WITH_WAIVER
BLOCKED_UNREVIEWED_GENERATION
BLOCKED_PENDING_INDEPENDENT_VERIFICATION
BLOCKED_SCRIPT_COVERAGE
BLOCKED_REFERENCE_EVIDENCE
BLOCKED_VISUAL_CONTRADICTION
BLOCKED_OVERLAY_OR_COMPOSITE
BLOCKED_MAX_ATTEMPTS
BLOCKED_ARTIFACT_INACCESSIBLE
BLOCKED_PROVIDER_MEDIA_URLS
BLOCKED_HUMAN_REVIEW_REQUIRED
```

Intermediate gates must be recorded in dedicated fields and must not be used as
final panel status values:

```text
script_coverage_status: PASS|FAIL|WAIVED
post_generation_script_coverage_status: PASS|FAIL|WAIVED
reference_evidence_status: PASS|FAIL|WAIVED
visual_review_status: PASS|FAIL|WAIVED
no_overlay_status: PASS|FAIL|WAIVED
provider_media_status: PASS|FAIL|WAIVED
```

A panel is provider-eligible only when final `status` is `PASS_PANEL_REVIEWED`
and every required subgate is `PASS`, or when a human waiver explicitly names
the failed requirement and downstream risk. A partial pass such as script-only,
reference-only, or DOM/report-only review must keep `provider_eligibility:
false`.

## Required Outputs

Return and persist:

```json
{
  "run_id": "string",
  "panel_id": "string",
  "status": "PASS_PANEL_REVIEWED|HUMAN_ACCEPTED_WITH_WAIVER|BLOCKED_...",
  "attempt": 1,
  "max_attempts": 4,
  "script_coverage_status": "PASS|FAIL|WAIVED",
  "post_generation_script_coverage_status": "PASS|FAIL|WAIVED",
  "reference_evidence_status": "PASS|FAIL|WAIVED",
  "visual_review_status": "PASS|FAIL|WAIVED",
  "no_overlay_status": "PASS|FAIL|WAIVED",
  "provider_media_status": "PASS|FAIL|WAIVED",
  "requirement_matrix": "/absolute/path/panel_requirement_matrix.json",
  "script_coverage_receipt": "/absolute/path/script_coverage_receipt.json",
  "post_generation_script_coverage_receipt": "/absolute/path/post_generation_script_coverage_receipt.json",
  "second_pass_script_delta": "/absolute/path/second_pass_script_delta.json",
  "reference_receipt": "/absolute/path/reference_receipt.json",
  "repair_prompt_package": "/absolute/path/repair_prompt_package.json",
  "generated_image_path": "/absolute/path/panel_01_attempt_02.png",
  "generation_receipt": "/absolute/path/scillm_generation_receipt.json",
  "visual_review_receipt": "/absolute/path/visual_review_receipt.json",
  "no_overlay_receipt": "/absolute/path/no_overlay_receipt.json",
  "provider_media_urls": ["https://..."],
  "media_hashes": {"panel": "sha256:..."},
  "provider_mode": "std",
  "provider_resolution": "720p",
  "callback_or_polling_plan": "/absolute/path/callback_or_polling_plan.json",
  "external_task_id": "project-stable-task-id",
  "voice_id_status": "PROVIDER_VOICE_ID_READY|SILENT_SCENE|BLOCKED_MISSING_PROVIDER_VOICE_ID",
  "cost_estimate": "/absolute/path/cost_estimate.json",
  "provider_packet_status": "BLOCKED_PROVIDER_GATE|DRY_RUN_NOT_LIVE_SUBMITTABLE|PROVIDER_READY",
  "status_transition_log": "/absolute/path/status_transition_log.jsonl",
  "provider_eligibility": false,
  "remaining_blockers": []
}
```

## Provider Boundary

This worker never performs a live paid provider call. It may update dry-run
provider eligibility fields, but live Kling execution remains blocked until the
`persona-dream` provider final gate passes.

The provider final gate must still verify:

- all panel gates pass;
- accepted storyboard and reference media are available as provider-accessible
  URLs or an approved upload plan exists;
- `mode` defaults to `std` / 720p unless explicitly approved otherwise;
- `external_task_id` is present;
- `callback_url` is reachable or a documented polling plan is accepted;
- every `<<<voice_n>>>` has a provider `voice_id` or the scene is explicitly
  silent;
- the cost estimate and retry budget are recorded.

`provider_eligibility` must remain `false` unless final `status` is
`PASS_PANEL_REVIEWED`, every required subgate is `PASS`, provider media URLs and
hashes are present, and the provider final gate requirements above are
represented in receipts.

## Output Standard

Report as an operational snapshot:

- Status/phase.
- Current panel and artifact paths.
- Evidence counts: required entities, missing entities, script failures,
  generation attempts, review receipts.
- Next stop condition or exact next command.

Do not claim storyboard/provider readiness from file existence, prompt text, or
DOM/report display alone.
