#!/usr/bin/env python3
"""Validate a persona-dream panel repair gate receipt.

This intentionally avoids an external jsonschema dependency so the gate can run
inside lightweight review and sanity environments.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


FINAL_STATUSES = {
    "PASS_PANEL_REVIEWED",
    "HUMAN_ACCEPTED_WITH_WAIVER",
    "BLOCKED_UNREVIEWED_GENERATION",
    "BLOCKED_PENDING_INDEPENDENT_VERIFICATION",
    "BLOCKED_SCRIPT_COVERAGE",
    "BLOCKED_REFERENCE_EVIDENCE",
    "BLOCKED_VISUAL_CONTRADICTION",
    "BLOCKED_OVERLAY_OR_COMPOSITE",
    "BLOCKED_MAX_ATTEMPTS",
    "BLOCKED_ARTIFACT_INACCESSIBLE",
    "BLOCKED_PROVIDER_MEDIA_URLS",
    "BLOCKED_HUMAN_REVIEW_REQUIRED",
}

PARTIAL_PASS_STATUSES = {
    "PASS_SCRIPT_COVERAGE",
    "PASS_REFERENCE_EVIDENCE",
    "PASS_VISUAL_REVIEW",
}

SUBGATES = [
    "script_coverage_status",
    "post_generation_script_coverage_status",
    "reference_evidence_status",
    "visual_review_status",
    "no_overlay_status",
    "provider_media_status",
]

REQUIRED_RECEIPTS = [
    "requirement_matrix",
    "script_coverage_receipt",
    "post_generation_script_coverage_receipt",
    "reference_receipt",
    "generation_receipt",
    "visual_review_receipt",
    "no_overlay_receipt",
]


def non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def validate_receipt(receipt: dict[str, Any], require_provider_eligible: bool) -> list[str]:
    errors: list[str] = []

    if receipt.get("schema") != "persona_dream.panel_repair_gate_receipt.v1":
        fail(errors, "schema must be persona_dream.panel_repair_gate_receipt.v1")

    for field in ("run_id", "panel_id"):
        if not non_empty_string(receipt.get(field)):
            fail(errors, f"{field} is required")

    status = receipt.get("status")
    if status in PARTIAL_PASS_STATUSES:
        fail(errors, f"{status} is an intermediate subgate, not a final panel status")
    if status not in FINAL_STATUSES:
        fail(errors, f"status must be one of {sorted(FINAL_STATUSES)}")

    for subgate in SUBGATES:
        value = receipt.get(subgate)
        if value not in {"PASS", "FAIL", "WAIVED"}:
            fail(errors, f"{subgate} must be PASS, FAIL, or WAIVED")

    for receipt_field in REQUIRED_RECEIPTS:
        if not non_empty_string(receipt.get(receipt_field)):
            fail(errors, f"{receipt_field} is required")

    provider_eligible = receipt.get("provider_eligibility")
    if not isinstance(provider_eligible, bool):
        fail(errors, "provider_eligibility must be boolean")

    remaining_blockers = receipt.get("remaining_blockers")
    if not isinstance(remaining_blockers, list) or not all(
        isinstance(item, str) for item in remaining_blockers
    ):
        fail(errors, "remaining_blockers must be a list of strings")

    if receipt.get("provider_mode") != "std" and not receipt.get("provider_mode_waiver"):
        fail(errors, "provider_mode must default to std unless provider_mode_waiver is true")

    if receipt.get("provider_resolution") != "720p" and not receipt.get("provider_mode_waiver"):
        fail(
            errors,
            "provider_resolution must default to 720p unless provider_mode_waiver is true",
        )

    if not non_empty_string(receipt.get("external_task_id")):
        fail(errors, "external_task_id is required")

    if not non_empty_string(receipt.get("callback_or_polling_plan")):
        fail(errors, "callback_or_polling_plan is required")

    voice_status = receipt.get("voice_id_status")
    if voice_status not in {
        "PROVIDER_VOICE_ID_READY",
        "SILENT_SCENE",
        "BLOCKED_MISSING_PROVIDER_VOICE_ID",
    }:
        fail(errors, "voice_id_status is invalid")

    if not non_empty_string(receipt.get("cost_estimate")):
        fail(errors, "cost_estimate is required")

    provider_urls = receipt.get("provider_media_urls")
    if not isinstance(provider_urls, list) or not provider_urls:
        fail(errors, "provider_media_urls must contain at least one URL")
    elif not all(isinstance(url, str) and url.startswith(("http://", "https://")) for url in provider_urls):
        fail(errors, "provider_media_urls must be provider-accessible http(s) URLs")

    media_hashes = receipt.get("media_hashes")
    if not isinstance(media_hashes, dict) or not media_hashes:
        fail(errors, "media_hashes must contain at least one sha256 hash")
    elif not all(isinstance(value, str) and value.startswith("sha256:") for value in media_hashes.values()):
        fail(errors, "media_hashes values must start with sha256:")

    provider_packet_status = receipt.get("provider_packet_status")
    if provider_packet_status not in {
        "BLOCKED_PROVIDER_GATE",
        "DRY_RUN_NOT_LIVE_SUBMITTABLE",
        "PROVIDER_READY",
    }:
        fail(errors, "provider_packet_status is invalid")

    hard_pass = (
        status == "PASS_PANEL_REVIEWED"
        and all(receipt.get(subgate) == "PASS" for subgate in SUBGATES)
        and voice_status in {"PROVIDER_VOICE_ID_READY", "SILENT_SCENE"}
        and receipt.get("provider_mode") == "std"
        and receipt.get("provider_resolution") == "720p"
        and provider_packet_status == "PROVIDER_READY"
        and isinstance(provider_urls, list)
        and bool(provider_urls)
        and isinstance(media_hashes, dict)
        and bool(media_hashes)
        and not remaining_blockers
    )

    if provider_eligible and not hard_pass:
        fail(errors, "provider_eligibility=true requires PASS_PANEL_REVIEWED and all provider subgates")

    if require_provider_eligible and not hard_pass:
        fail(errors, "receipt is not provider eligible")

    if status == "PASS_PANEL_REVIEWED" and not hard_pass:
        fail(errors, "PASS_PANEL_REVIEWED requires all subgates and provider fields to pass")

    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("receipt", type=Path)
    parser.add_argument(
        "--require-provider-eligible",
        action="store_true",
        help="Fail unless the receipt is provider-eligible.",
    )
    args = parser.parse_args(argv)

    receipt = json.loads(args.receipt.read_text())
    errors = validate_receipt(receipt, args.require_provider_eligible)
    if errors:
        print(json.dumps({"status": "FAIL", "errors": errors}, indent=2))
        return 1

    print(json.dumps({"status": "PASS", "receipt": str(args.receipt)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
