# Prompt Improvements for the Next WebGPT Round

For the next request, include these artifacts explicitly:

1. The actual committed files touched after this bundle is ported.
2. The exact output of:
   - `python3 skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py --root .`
   - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q skills/watch/tests/test_watch_realtime_identity_memory_loop_P1.py`
3. The current `git diff --stat` and `git status --short`, especially to confirm no unrelated UI files were rewritten.
4. Any real Qdrant/Arango/Jina connection details should be represented as sanitized command logs, not secrets.
5. For live identity proof, include approved reference image manifests and their provenance/approval status, not only Brave Search URLs.
6. For row text, include the missing `srt_text` source ref repair or keep the receipt blocked.
7. Separate dry-run, mocked-service, and live proof sections. Do not mix them.
8. State whether the next requested slice is:
   - reference approval + embedding write,
   - trace observation writer,
   - memory recall reader,
   - overlay adapter wiring,
   - or evidence case creation.

Avoid phrasing that asks WebGPT to “approve” or “pass” this slice unless the request is explicitly a review. For creation requests, ask for either a corrected solution zip or numbered clarifying questions.
