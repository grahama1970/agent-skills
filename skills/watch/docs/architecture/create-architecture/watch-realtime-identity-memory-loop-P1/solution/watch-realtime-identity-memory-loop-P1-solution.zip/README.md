# Watch Realtime Identity Memory Loop P1 Solution Bundle

This bundle is an implementation-ready architecture package for `watch-realtime-identity-memory-loop-P1`.
It is scoped to contracts, schemas, fixtures, tests, commands, and precise patch guidance for the Watch skill in `agent-skills`.

The package deliberately does **not** claim that live identity, Qdrant persistence, Arango persistence, or memory recall have already been proven. It defines the P1 contracts and deterministic dry-run fixtures needed to implement and verify those rungs locally.

## Scope decisions made

- Runtime default: Ultralytics YOLO detection plus ByteTrack tracking.
- Verification cadence: 5 FPS starting target, enforced as a bounded scheduler rather than per-frame identity inference.
- Movie/cinema assets: auto-plan cast/character reference hydration before ingest/tracking.
- Drone, ITAR, RTSP, and YouTube assets: require a source-provided reference manifest or fail closed; do not default to public search.
- Brave Search/cast metadata: reference candidates only, never scene truth.
- Detector labels: observation proposals only, never named identity truth.
- Identity promotion: requires approved references plus source evidence and later memory recall proof.
- Arango: metadata and Qdrant point ids only; no raw vectors.
- Qdrant/Jina: multimodal/text embeddings for references, crops, row text, and segments.
- UI: specify event contract for existing modal/player; do not redesign Watch table/chat.

## Main files

- `ARCHITECTURE.md` - full P1 contract.
- `repo/skills/watch/docs/architecture/watch_realtime_identity_memory_loop_P1.md` - repo-relative architecture document.
- `repo/skills/watch/docs/architecture/watch_realtime_identity_state_machine_P1.md` - state machine and fail-closed behavior.
- `repo/skills/watch/docs/architecture/watch_memory_persistence_contract_P1.md` - Qdrant/Arango/memory write/read contracts.
- `repo/skills/watch/docs/architecture/watch_realtime_overlay_event_contract_P1.md` - overlay event contract.
- `repo/skills/watch/docs/architecture/schemas/*.schema.json` - implementation schemas.
- `repo/skills/watch/tests/test_watch_realtime_identity_memory_loop_P1.py` - deterministic P1 contract tests.
- `repo/skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/*` - fixtures for P1 edge cases and dry-run expected behavior.
- `repo/skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py` - stdlib validation harness.
- `PATCH_PLAN.md` - file-by-file patch plan.
- `COMMANDS.md` - exact local commands.
- `ROLLBACK_REBUILD.md` - rollback/rebuild plan.
- `KNOWN_GAPS.md` - claims not made by this bundle.
- `prompt_improvements.md` - next-round request improvements.
