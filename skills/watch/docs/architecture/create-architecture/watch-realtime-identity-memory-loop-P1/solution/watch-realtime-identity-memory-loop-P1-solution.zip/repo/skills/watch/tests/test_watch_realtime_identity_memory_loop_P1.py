from __future__ import annotations

import json
from pathlib import Path

from skills.watch.scripts.validate_watch_realtime_identity_memory_loop_P1 import assert_no_raw_vectors, validate

ROOT = Path(__file__).resolve().parents[3]
FIXTURES = ROOT / "skills" / "watch" / "tests" / "fixtures" / "realtime_identity_memory_loop_P1"


def load_json(name: str):
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


def load_jsonl(name: str):
    return [json.loads(line) for line in (FIXTURES / name).read_text(encoding="utf-8").splitlines() if line.strip()]


def test_p1_fixture_contracts_validate():
    validate(ROOT)


def test_movie_assets_auto_plan_reference_hydration_without_identity_promotion():
    plan = load_json("movie_asset_reference_plan.json")
    assert plan["asset_type"] == "movie"
    assert plan["reference_source_policy"] == "MOVIE_DOMAIN_AUTO_DISCOVERY"
    assert plan["public_search_allowed"] is True
    assert plan["candidate_source_refs"]
    assert plan["approved_reference_count"] == 0
    assert plan["identity_promotion_allowed"] is False


def test_drone_without_source_manifest_fails_closed_and_disables_public_search():
    plan = load_json("drone_missing_reference_manifest_fail_closed.json")
    assert plan["asset_type"] == "drone"
    assert plan["reference_source_policy"] == "SOURCE_MANIFEST_REQUIRED"
    assert plan["public_search_allowed"] is False
    assert plan["identity_promotion_allowed"] is False
    assert plan["failure_code"] == "SOURCE_REFERENCE_MANIFEST_REQUIRED"


def test_yolo_bytetrack_events_are_observations_not_identity():
    events = load_jsonl("realtime_track_events.jsonl")
    assert len(events) >= 3
    assert all(event["detector"]["name"] == "ultralytics_yolo" for event in events)
    assert all(event["tracker"]["name"] == "bytetrack" for event in events)
    assert all(event["identity_status"] == "OBSERVATION_ONLY" for event in events)


def test_identity_verification_stays_inconclusive_without_approved_references():
    result = load_json("identity_verification.inconclusive.json")
    assert result["approved_reference_count"] == 0
    assert result["identity_status"] == "IDENTITY_INCONCLUSIVE"
    assert result["promotion_allowed"] is False
    assert "DOMAIN_PRIOR_ONLY" in result["failure_codes"]


def test_arango_fixture_uses_qdrant_pointers_not_raw_vectors():
    doc = load_json("arango_metadata_doc.no_vectors.json")
    assert doc["qdrant_point_ids"]
    assert_no_raw_vectors(doc)


def test_overlay_event_can_render_without_claiming_supported_identity():
    overlay = load_json("ui_realtime_overlay_event.inconclusive.json")
    assert overlay["schema"] == "watch.ui_realtime_overlay_event.v1"
    assert overlay["track_id"] == "track_person_0248_0007"
    assert overlay["bbox"]["normalized"] is True
    assert overlay["identity_status"] == "IDENTITY_INCONCLUSIVE"
    assert overlay["identity_status"] != "IDENTITY_SUPPORTED"
    assert "not_live_identity_proof" in overlay["proof_scope"]
