# Known Gaps and Claim Boundaries

This bundle is an architecture and implementation-ready contract package. It intentionally does not claim these have been proven:

- live YOLO/ByteTrack execution in the current browser/modal,
- named identity support for Marcus, Willie, or any movie character,
- approved reference-image embeddings,
- Qdrant writes,
- Arango writes,
- memory persistence,
- `$memory recall` retrieval,
- Watch evidence-case creation from live memory,
- multi-drone AO command and control,
- UI redesign or polished overlay behavior.

Current evidence described by the creation bundle remains bounded:

- YOLO/ByteTrack event artifacts exist for a Bad Santa canary.
- 10 overlay records and 10 crop artifacts exist for one segment.
- Identity verification currently returns 10 inconclusive and 0 supported identities.
- Brave Search produced public candidate links, not approved reference images.
- Row-text materialization is blocked pending a missing `srt_text` source ref.
- Qdrant/Arango writes are planned only.

A future progress claim should use this wording until live proof exists:

```text
P1 contracts, fixtures, and dry-run fail-closed validation are installed for Watch realtime identity memory loop.
```

Do not claim:

```text
Watch can now find all movie segments with Willie from memory.
Watch has proven live identity support.
Qdrant/Arango/memory persistence is complete.
```
