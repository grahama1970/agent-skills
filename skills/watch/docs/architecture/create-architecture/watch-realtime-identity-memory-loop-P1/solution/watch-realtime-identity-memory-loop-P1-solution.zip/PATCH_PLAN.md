# File-by-file Patch Plan

This plan is precise and bounded. It avoids dirty/unrelated Watch UI files and does not redesign table/chat.

## 1. Documentation contracts

Create:

- `skills/watch/docs/architecture/watch_realtime_identity_memory_loop_P1.md`
- `skills/watch/docs/architecture/watch_realtime_identity_state_machine_P1.md`
- `skills/watch/docs/architecture/watch_memory_persistence_contract_P1.md`
- `skills/watch/docs/architecture/watch_realtime_overlay_event_contract_P1.md`
- `skills/watch/docs/architecture/watch_reference_hydration_lifecycle_P1.md`
- `skills/watch/docs/architecture/watch_ml_tracking_runtime_P1.md`

Do not modify UI components in this slice except for later adapter wiring to consume `watch.ui_realtime_overlay_event.v1`.

## 2. Schemas

Create:

- `skills/watch/docs/architecture/schemas/watch_asset_reference_hydration_plan_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_reference_manifest_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_realtime_track_event_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_ui_realtime_overlay_event_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_identity_verification_result_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_trace_observation_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_memory_write_receipt_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_recall_receipt_P1.schema.json`
- `skills/watch/docs/architecture/schemas/watch_evidence_case_P1.schema.json`

Each schema includes a `schema` const so downstream artifacts self-identify their contract.

## 3. Validation script

Create:

- `skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py`

This script is deliberately stdlib-only. It validates the bundled fixture invariants that matter for P1:

- movie assets auto-plan reference hydration,
- restricted streams require source manifests,
- identity remains inconclusive without approved references,
- Arango docs do not contain raw vectors,
- overlay events carry track ids, bbox, TTL/stale semantics, and non-supported identity state,
- evidence case fixture has both entity ids and time range.

## 4. Tests and fixtures

Create:

- `skills/watch/tests/test_watch_realtime_identity_memory_loop_P1.py`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/movie_asset_reference_plan.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/drone_missing_reference_manifest_fail_closed.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/realtime_track_events.jsonl`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/ui_realtime_overlay_event.inconclusive.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/identity_verification.inconclusive.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/trace_observation.memory_planned.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/arango_metadata_doc.no_vectors.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/memory_write_receipt.planned.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/recall_receipt.verified.example.json`
- `skills/watch/tests/fixtures/realtime_identity_memory_loop_P1/evidence_case.anchored.example.json`

## 5. Existing scripts integration points

Update in later local implementation, not inside this architecture-only package unless the repo owner chooses to port code directly:

- `skills/watch/scripts/watch_reference_hydration.py`
  - emit `watch.asset_reference_hydration_plan.v1`, enforce asset policy matrix.
- `skills/watch/scripts/build_identity_reference_manifest.py`
  - distinguish candidate, downloaded, pending approval, approved, embedded.
- `skills/watch/scripts/extract_tracking_crops.py`
  - emit track crop refs keyed by `track_id`, `frame_ref`, `media_time_s`, `bbox`.
- `skills/watch/scripts/verify_tracking_identity.py`
  - consume approved references only for promotion; return `INCONCLUSIVE` otherwise.
- `skills/watch/scripts/build_watch_row_text_materialization_receipt_plan.py`
  - keep blocking if any required channel source ref is missing.

## 6. Memory implementation integration points

Add a Watch memory writer/reader adapter in a later code slice:

- `skills/watch/scripts/write_watch_trace_memory.py`
- `skills/watch/scripts/recall_watch_trace_memory.py`

The writer must:

- embed with Jina/Qdrant,
- store metadata and point ids in Arango,
- produce an idempotent receipt,
- never store raw vectors in Arango.

The reader must:

- be invoked only after intent classification and entity extraction,
- query memory rather than UI text,
- return grounded source refs and trace observation ids,
- create evidence cases only when bounded anchors are required.
