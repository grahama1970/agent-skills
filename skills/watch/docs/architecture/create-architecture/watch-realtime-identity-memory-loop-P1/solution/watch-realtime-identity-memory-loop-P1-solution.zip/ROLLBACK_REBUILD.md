# Rollback and Rebuild Plan

## Rollback

The P1 bundle is additive. To roll it back from a working tree:

```bash
git status --short
rm -f skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py
rm -f skills/watch/tests/test_watch_realtime_identity_memory_loop_P1.py
rm -rf skills/watch/tests/fixtures/realtime_identity_memory_loop_P1
rm -f skills/watch/docs/architecture/watch_realtime_identity_memory_loop_P1.md
rm -f skills/watch/docs/architecture/watch_realtime_identity_state_machine_P1.md
rm -f skills/watch/docs/architecture/watch_memory_persistence_contract_P1.md
rm -f skills/watch/docs/architecture/watch_realtime_overlay_event_contract_P1.md
rm -f skills/watch/docs/architecture/watch_reference_hydration_lifecycle_P1.md
rm -f skills/watch/docs/architecture/watch_ml_tracking_runtime_P1.md
rm -f skills/watch/docs/architecture/schemas/watch_*_P1.schema.json

git status --short
```

No database rollback is required for this architecture bundle because it performs no live Qdrant, Arango, or memory writes.

## Rebuild deterministic artifacts

```bash
python3 skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py --root .
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q skills/watch/tests/test_watch_realtime_identity_memory_loop_P1.py
```

## Live persistence rollback, for the later implementation slice

When live Qdrant/Arango writes are implemented, every write command must emit a rollback manifest containing:

- Qdrant collection names and point ids created,
- Arango collection names and document keys created or updated,
- previous Arango document snapshots for updates,
- memory receipt ids,
- asset id, run id, and command args.

Rollback command shape:

```bash
python3 skills/watch/scripts/rollback_watch_trace_memory.py \
  --rollback-manifest skills/watch/docs/architecture/generated/<run>/rollback_manifest.json \
  --qdrant-url "$QDRANT_URL" \
  --arango-url "$ARANGO_URL" \
  --apply
```

Rollback must delete created Qdrant points and restore Arango docs to their pre-apply pointer state. It must not rely on vector contents being stored in Arango.
