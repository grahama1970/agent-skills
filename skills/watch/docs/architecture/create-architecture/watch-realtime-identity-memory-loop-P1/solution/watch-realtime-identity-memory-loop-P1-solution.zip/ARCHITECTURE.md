# Architecture Contract: Watch Realtime Identity Memory Loop P1

## Objective

Watch must treat movies as a controlled test case for future AO / multi-stream / drone video memory. The P1 architecture connects four previously separate lanes:

1. reference hydration before ingest,
2. realtime YOLO + ByteTrack observation streaming,
3. bounded identity verification against approved references plus source context,
4. memory persistence and recall through Watch's memory pipeline.

P1 is not a UI redesign. The existing Watch table/chat/modal remains the consumer. The work here is the contract layer that prevents static annotations, public search, or detector labels from being mistaken for grounded identity memory.

## Non-negotiable boundaries

| Input | May be used as | Must not be used as |
| --- | --- | --- |
| Movie cast/character metadata from Brave Search | reference-source candidate discovery | scene truth, segment visibility proof, identity support |
| Public web reference images | candidate references pending approval | approved reference evidence without review/manifest acceptance |
| YOLO labels | object/person observation proposals | named character identity |
| ByteTrack track ids | temporal continuity of an observation | person/character identity |
| SRT/Whisper/row text | aligned context/source evidence | standalone visual identity proof |
| Qdrant/Jina embeddings | similarity/recall support | authoritative identity source |
| Arango | structured metadata, graph edges, Qdrant point ids | raw vector store |
| `$memory recall` | official user-facing retrieval path | optional bypassable layer |

## Chosen ML default

Use Ultralytics YOLO plus ByteTrack for P1.

Rationale:

- It is practical and already aligned with the current local Bad Santa canary evidence.
- YOLO is enough for person/object observation proposals at this rung.
- ByteTrack gives stable-enough track continuity for a bounded verification scheduler.
- It keeps P1 focused on contracts and evidence promotion rather than tracker research.

P1 may later add stronger detectors, ReID, face models, or domain-specific aerial models, but those must plug into the same event and identity contracts rather than replacing the memory semantics.

## Runtime topology

```text
asset registered
  -> reference hydration planner
  -> reference source candidate collection / source manifest validation
  -> reference images downloaded or loaded from manifest
  -> human/source approval gate
  -> reference embeddings planned/created
  -> ingest ready
  -> frame decode
  -> YOLO detections
  -> ByteTrack track ids
  -> watch.realtime_track_event.v1 JSONL
  -> bounded crop/frame sampler at 5 FPS target
  -> identity verifier
  -> watch.trace_observation.v1
  -> row text materialization receipt
  -> memory write planner
  -> Qdrant/Jina embedding writes + Arango metadata/pointers
  -> memory recall proof
  -> evidence case only when bounded entity/time anchoring is required
```

## Asset policy matrix

| Asset class | Reference source policy | Public search default | Fail-closed condition |
| --- | --- | --- | --- |
| `movie`, `cinema`, `episode` | auto-plan cast/character candidate hydration | allowed for candidates only | ingest/tracking identity promotion disabled until approved reference package exists |
| `drone`, `ITAR`, `AO`, `RTSP`, `YouTube`, `security_camera` | source-provided manifest / registry / telemetry manifest | disabled by default | no source manifest or no approved reference package |
| unknown | require explicit policy | disabled | unknown asset class |

## Verification cadence

The starting cadence is 5 FPS per stream as an upper bound for verification samples, not a requirement to run identity inference on every frame. ByteTrack track continuity remains continuous; identity verification is sampled.

Implementation defaults:

```yaml
verification:
  target_fps_per_stream: 5
  max_samples_per_second_per_stream: 5
  min_interval_ms_per_track: 200
  max_active_tracks_per_frame: 32
  crop_strategy: latest_high_quality_bbox
  stale_after_ms: 1000
  identity_support_requires:
    - approved_reference_embedding
    - track_crop_or_frame_embedding
    - source_context_ref
    - segment_or_time_range_ref
    - no_refuting_evidence
```

## Identity promotion rules

Identity states are fail-closed:

- `IDENTITY_CANDIDATE`: possible entity label attached to a track from references/context; not a claim.
- `IDENTITY_INCONCLUSIVE`: default when approved references or source evidence are missing, ambiguous, or conflicting.
- `IDENTITY_SUPPORTED`: only after approved references, visual similarity evidence, source context, and bounded trace evidence pass thresholds.
- `IDENTITY_REFUTED`: evidence contradicts a candidate identity.
- `NEEDS_HUMAN_REVIEW`: evidence may be relevant but approval/confidence is insufficient.

Promotion is forbidden when any of these are true:

- only detector labels exist,
- only public search/cast metadata exists,
- reference images are candidates but not approved,
- row text materialization is blocked pending source refs,
- Qdrant or Arango write is only planned,
- recall proof has not been performed for user-facing memory claims.

## Memory pipeline semantics

User-facing recall must follow this reasoning contract:

1. intent classification,
2. entity extraction,
3. memory recall,
4. evidence case creation only when bounded case anchoring is required,
5. answer, clarify, or deflect from grounded evidence.

The stage names are architecture stages, not executable slash commands. Direct scraping of visible UI text is not a valid recall path.

## Persistence contract summary

Qdrant stores embeddings and payload ids for:

- approved reference images,
- track crops/frame samples,
- row text/materialized segment text,
- optional source-manifest descriptions.

Arango stores:

- asset metadata,
- source refs,
- reference candidates/approved references,
- track observations,
- trace observations,
- Qdrant point ids,
- row text receipt ids,
- evidence case anchors,
- graph edges among assets, entities, tracks, segments, sources, and cases.

Arango must never store raw embedding arrays.

## Evidence case creation rule

`watch_evidence_cases` are created only when the system needs a bounded case anchor. A case must include:

- `entity_ids` with identity state and evidence status,
- `time_range` with asset/stream/segment refs,
- source refs used for row text/context,
- observation refs and crop/frame artifact refs,
- Qdrant point ids and Arango doc ids,
- verdict separate from failure code.

Do not create evidence cases for every track event. Persist trace observations first; create cases only for bounded question-answering, adjudication, or review.

## P1 acceptance evidence ladder

P1 local implementation should separate proof levels:

### Dry-run contract proof

- Schemas parse.
- Fixtures validate.
- Non-movie asset without source manifest fails closed.
- Movie asset creates reference hydration plan before ingest.
- Identity verifier stays inconclusive when only detector labels/domain priors exist.
- Arango fixture docs contain Qdrant point ids and no raw vectors.
- Overlay event fixture renders identity as candidate/inconclusive, not supported.

### Local mocked-service proof

- Qdrant/Arango clients can be replaced by fake clients returning deterministic point ids and document ids.
- Memory write receipts are deterministic and idempotent.
- Recall planner uses the memory pipeline and does not scrape UI row text.

### Live proof before promotion claims

- Real approved reference image fixture embedded through Jina/Qdrant.
- Real track crop embeddings written to Qdrant.
- Real Arango documents written with point ids only.
- Real `$memory recall` retrieves the Watch trace evidence by entity and time range.
- Evidence case creation produces a bounded case only when entity + time evidence exists.
