# Exact Commands

Run these from the root of `agent-skills` after copying the `repo/` tree from this bundle into the repository.

## Copy bundle files into the repo

```bash
unzip watch-realtime-identity-memory-loop-P1-solution.zip -d /tmp/watch-p1-solution
rsync -av /tmp/watch-p1-solution/repo/ ./
```

## Dry-run contract checks

```bash
python3 -m py_compile \
  skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py

python3 skills/watch/scripts/validate_watch_realtime_identity_memory_loop_P1.py --root .

PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q \
  skills/watch/tests/test_watch_realtime_identity_memory_loop_P1.py
```

Expected dry-run output:

```text
p1_contracts_ok
7 passed
```

Exact test count may increase if the project agent splits assertions into more tests. Do not claim live proof from dry-run fixture tests.

## Existing canary commands to keep separate

These commands reference existing local artifacts named in the creation bundle. They may require the repo's current arguments; keep their proof level separate.

```bash
python3 skills/watch/scripts/extract_tracking_crops.py \
  --tracker-events skills/watch/docs/architecture/generated/bad_santa_marcus_0248_yolo_bytetrack/watch_tracker_event_log.bad_santa_marcus.yolo_bytetrack.jsonl \
  --out-dir skills/watch/docs/architecture/generated/bad_santa_marcus_0248_tracking_crops

python3 skills/watch/scripts/verify_tracking_identity.py \
  --tracking-crops skills/watch/docs/architecture/generated/bad_santa_marcus_0248_tracking_crops/watch_tracking_crops.bad_santa_marcus.json \
  --reference-manifest skills/watch/docs/architecture/generated/bad_santa_marcus_0248_identity_references/watch_identity_reference_manifest.bad_santa_marcus.json \
  --out skills/watch/docs/architecture/generated/bad_santa_marcus_0248_identity_verification/watch_identity_verification.bad_santa_marcus.json

python3 skills/watch/scripts/build_identity_reference_manifest.py \
  --out skills/watch/docs/architecture/generated/bad_santa_marcus_0248_identity_references/watch_identity_reference_manifest.bad_santa_marcus.json

python3 skills/watch/scripts/build_watch_row_text_materialization_receipt_plan.py \
  --out skills/watch/docs/architecture/generated/bad_santa_marcus_0248_row_text_materialization_receipt_plan/watch_row_text_materialization_receipt_plan.bad_santa_marcus.json
```

Expected current canary behavior remains fail-closed:

```text
supported_count 0
inconclusive_count 10
status BLOCKED_PENDING_SOURCE_REFS
materialized_text_channel_count 0
```

## Local mocked-service proof commands, after writer/reader implementation

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q \
  skills/watch/tests/test_watch_memory_writer_fake_clients.py \
  skills/watch/tests/test_watch_memory_recall_fake_clients.py
```

The fake-client tests must prove deterministic ids, idempotence, and no raw vectors in Arango payloads.

## Live proof commands, only when real services are configured

Do not run these as proof unless Qdrant, Arango, the Jina embedding path, and the Watch memory adapter are live.

```bash
python3 skills/watch/scripts/write_watch_trace_memory.py \
  --trace-observations skills/watch/docs/architecture/generated/bad_santa_marcus_0248_trace_observations/watch_trace_observations.bad_santa_marcus.jsonl \
  --row-text-receipt skills/watch/docs/architecture/generated/bad_santa_marcus_0248_row_text_materialization_receipt_plan/watch_row_text_materialization_receipt_plan.bad_santa_marcus.json \
  --qdrant-url "$QDRANT_URL" \
  --arango-url "$ARANGO_URL" \
  --write

python3 skills/watch/scripts/recall_watch_trace_memory.py \
  --query "find all movie segments with Willie" \
  --asset-id bad_santa_2003_canary \
  --require-memory-recall-proof \
  --out skills/watch/docs/architecture/generated/bad_santa_marcus_0248_recall/watch_recall_receipt.bad_santa_marcus.json
```

Required live proof before user-facing claims:

- Qdrant points exist for approved references and trace crops/row text.
- Arango docs contain point ids and source refs, not raw vectors.
- Recall result includes grounded trace observation ids and source refs.
- Evidence case creation only happens when entity ids and time range evidence are both present.
