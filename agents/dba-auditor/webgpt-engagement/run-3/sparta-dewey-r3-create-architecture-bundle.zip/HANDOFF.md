# Handoff Report: Dewey (dba-auditor) Nightly Monitor-Sparta Repair Loop

**Timestamp**: 2026-06-24T19:00:00Z  
**Active Agent**: OpenCode  
**Project Root**: `/home/graham/workspace/experiments/agent-skills/agents/dba-auditor`

## 1. Project Overview

- **Ecosystem**: Python + shell + ArangoDB + scillm/Chutes
- **Core Purpose**: Dewey is the DBA Auditor cron agent that runs `/monitor-sparta repair-cycle` nightly until 29/29 PASS. It reads coverage gaps from monitor-sparta health checks and attempts to fix them through the repair-cycle pipeline.
- **Key repos**: `agent-skills` (Dewey scripts in `agents/dba-auditor/`), `memory` (monitor_sparta.py, services.yaml)

## 2. Current State

### What is working
- **Reading coverage gaps**: √ `health --json` completes in ~65s and shows 23/29 PASS with clear failing dimensions
- **Per-cycle logging**: √ `dewey.log` shows START, BUDGETS, BASELINE, CYCLE_START, REPAIR_STEP, STOP with timestamps and durations
- **repair-cycle completes**: √ Now finishes in ~356s (was timing out before R2 timeout fix)
- **Named step output**: √ Steps now include `id` (e.g. `sparta_qdrant_embed_batch`, `monitor_health_fix`, `create_qras_backfill`)
- **Unfixable dim classification**: √ `sparta_explorer_page_purpose` and `qra_coverage_per_control` correctly tagged
- **Morning report**: √ Written on every run with stop_reason, final health, remaining failures
- **Unit tests**: 19/19 passing
- **`once` and `start` subcommands**: Both functional
- **Calibrated timeouts**: `--repair-timeout-s`, `--wait-timeout-s`, `--embed-batch-limit` all configurable

### What is broken / not proven

1. **repair-cycle fixes nothing**: Despite completing, zero health dimensions improve after a full cycle. Same 5 dims failing before and after: `embedding_gaps`, `description_completeness`, `inline_embedding_policy`, `qra_coverage_per_control`, `sparta_explorer_page_purpose`

2. **Embed lane silently no-ops**: `sparta_qdrant_embed_batch` with `--embed-batch-limit 200` processes 200 docs but drops all 200 (already in Qdrant). Yet `embedding_gaps` dimension reports 170 missing. Health check and embed batch are checking different things — no `eligible_count`, `changed_count`, or `skip_reason` in step output.

3. **Health --fix doesn't progress**: `monitor_health_fix` runs for 165s but the same 5 dims are still failing after. No per-dimension fix result (skipped/attempted/succeeded/failed).

4. **Worker wait always times out**: `create_qras_backfill` launches a worker then `_wait_for_monitor_workers` polls until wait_timeout_s (300s). The worker is still running after 300s. No evidence the worker ever completes or creates QRAs.

5. **QRA lane contract ambiguous**: `qra_coverage_per_control` is in both `UNFIXABLE_DIMENSIONS` AND has a `create_qras_backfill` repair lane. These conflict. Need to decide: is it repairable via scillm/Chutes or operator-required?

6. **Step output missing detail**: Steps have `id` and `duration_s` but not `eligible_count`, `changed_count`, `command`, `rc`, `skip_reason`, or before/after failed dimensions.

## 3. What WebGPT Already Provided (R1 + R2)

- R1: `dewey-P0-solution.zip` — initial orchestrator with stall tracking, health diff, morning report
- R2: `dewey-P0-r2-fixes.zip` — fixed timeout calibration, unfixable dim handling, db_session_command flags
- Both ported and tested. 19/19 unit tests pass.

## 4. What WebGPT Still Needs to Fix (R3)

The next engagement must fix inside `monitor_sparta.py repair-cycle`:

1. **Embed step**: Add `eligible_count`, `changed_count`, `skip_reason`. Resolve why health check says 170 missing but embed batch finds 0.
2. **Health --fix**: Report per-dimension result (skipped/attempted/succeeded/failed) with affected record count.
3. **Worker wait**: Track whether QRA worker eventually completes and creates QRAs. Don't just timeout.
4. **QRA lane**: Resolve contract (unfixable vs scillm/Chutes repair). If repairable, implement bounded scillm QRA lane with model pool config.
5. **DeepSeek V4**: If QRA generation should use DeepSeek V4 instead of `qra-deepseek-pool`, configure as scillm model pool change.

## 5. Key Files

| File | Purpose |
|------|---------|
| `agent-skills/agents/dba-auditor/scripts/dewey_overnight_run.py` | Dewey orchestrator (start/once) |
| `agent-skills/agents/dba-auditor/scripts/dewey_nightly_cron.sh` | Cron wrapper with flock |
| `agent-skills/agents/dba-auditor/scripts/db_repair_session.py` | Backup/verify/revert session |
| `agent-skills/agents/dba-auditor/scripts/sanity_live_repair_cycle_smoke.sh` | Live smoke test |
| `agent-skills/agents/dba-auditor/tests/test_dewey_monitor_sparta_nightly.py` | 19 unit tests |
| `memory/scripts/validation/monitor_sparta.py` | 10,780-line health check + repair-cycle |
| `memory/.agents/services.yaml` | Cron service config (disabled) |
| `agent-skills/agents/dba-auditor/webgpt-engagement/run-3/creation-bundle.md` | R3 bundle (current WebGPT engagement) |

## 6. Next Steps

1. Submit R3 creation bundle to WebGPT via the sparta explorer tab (837355531)
2. WebGPT returns zip fixing repair-cycle step detail + QRA lane contract
3. Port and test the fix
4. Re-enable Dewey cron (`enabled: true` in services.yaml)
5. Verify Dewey can read gaps AND fix them in a single overnight run

## 7. WebGPT Tab

- **Tab ID**: 837355531
- **URL**: `https://chatgpt.com/g/g-p-6a22b674b76881918809ceac4396a409-sparta-explorer/c/6a3af580-53c8-83ea-a301-ecfc6fc49f87`
- **Desktop**: 2
- **Project**: sparta
